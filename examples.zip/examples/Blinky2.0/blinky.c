#include <vega/hal.h>
#include <vega/aries.h>

int main()
{
    GPIO_Init(GPIOB, LED_3, GPIO_OUT);
    GPIO_Init(GPIOB, LED_2, GPIO_OUT);

    LED_3_RST;
    LED_2_RST;

    while (1) {
        LED_3_SET; // set -> 0 = 0n
        delayms(500);
        LED_3_RST; // reset-> 1 = off
        delayms(500);
        
        // rgb led is common anode
        // led on => digital low
        // led off => digital high

        LED_2_SET; 
        delayms(500); 
        LED_2_RST;
        delayms(500);

    }
    
    return 0;
}