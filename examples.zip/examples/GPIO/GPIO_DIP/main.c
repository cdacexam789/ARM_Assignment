/* This example assumes ARIESv2 board being used */

#include <vega/hal.h>
#include <vega/aries.h>

int main()
{

    for (int i = 4; i < 6; i++) {
        GPIO_Init(GPIOB, i, GPIO_OUT);
        GPIO_SetPin(GPIOB, i);
    }

    GPIO_Init(GPIOB, 1, GPIO_IN);
    GPIO_Init(GPIOB, 0, GPIO_IN);
    
    while (1) {
        // Check Button 0 is pressed
        if (GPIO_ReadPin(GPIOB, SWITCH0) == 0) {
            LED_3_SET;
            LED_2_RST;
        }

        // Check Button 1 is pressed
        else if (GPIO_ReadPin(GPIOB, SWITCH1) == 0) {
            LED_2_SET;
            LED_3_RST;
        }
        else {
            LED_2_SET;
            LED_3_SET;
        }
    }

    return 0;
}