#include <vega/hal.h>
#include <vega/aries.h>

int main()
{
    GPIO_Init(GPIOB, RGB_RED, GPIO_OUT);
    GPIO_Init(GPIOB, RGB_GREEN, GPIO_OUT);
    GPIO_Init(GPIOB, RGB_BLUE, GPIO_OUT);

    RGB_RED_RST;
    RGB_GREEN_RST;
    RGB_BLUE_RST;

    while (1) {
        RGB_RED_SET; // reset -> 0 = 0n
        delayms(100);
        RGB_RED_RST; // set-> 1 = off
        delayms(100);
        
        // rgb led is common anode
        // led on => digital low
        // led off => digital high

        RGB_GREEN_SET; // reset -> 0 = 0n
        delayms(100); 
        RGB_GREEN_RST;
        delayms(100);

        RGB_BLUE_SET; // reset -> 0 = 0n
        delayms(100);
        RGB_BLUE_RST;
        delayms(100); 
    }
    
    return 0;
}